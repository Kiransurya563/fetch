package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Employeedao;
import dto.Employee;

@WebServlet("/insertdata")
public class Employeecontroller extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// super.doPost(req, resp);

		String name = req.getParameter("name");
		String number = req.getParameter("number");
		int number1=Integer.parseInt(number);
		String email = req.getParameter("email");
		String gender = req.getParameter("gender");
		
		
		Employee employee=new Employee();
		employee.setName(name);
		employee.setPhonenumber(number1);
		employee.setEmail(email);
		employee.setGender(gender);
		
		Employeedao employeedao=new Employeedao();
		employeedao.insert(employee);
	}
}
